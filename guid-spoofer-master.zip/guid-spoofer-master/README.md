# GUID Spoofer
This will spoof your Universally Unique Identifier(GUID)

## Description
#### This tool changes your GUID, this may be used to avoid anti-cheats punishments and much more!

## T.O.S
![APM](https://img.shields.io/apm/l/vim-mode?style=for-the-badge)
###### This repository/project is under MIT licence, if you are using it please leave watermark to the owner. (github.com/owersite)


### Preview:
![preview](ex.gif)




## Disclaimer:
#### Owersite(creator) is not is not resposible for whatever you do with this, it is made for educational purposes only!
